# coding=utf8
# 获取和处理 CVE json 文件
# 该代码用于从 NIST 下载自 2002 年至当前年的 nvdcve 压缩文件，
# 解压并将所有 JSON 文件合并在一起，
# 并提取项目的所有条目。

import datetime
import json
import os
import re
from io import BytesIO
import pandas as pd
import requests
from pathlib import Path
from zipfile import ZipFile
from pandas import json_normalize

from extract_cwe_record import add_cwe_class, extract_cwe
import configuration as cf
import database as db

# ---------------------------------------------------------------------------------------------------------------------

# 基础 URL 组件用于下载 CVE 数据
urlhead = 'https://nvd.nist.gov/feeds/json/cve/1.1/nvdcve-1.1-'
urltail = '.json.zip'
initYear = 2023  # 初始年份设为 2023
currentYear = datetime.datetime.now().year  # 当前年份

# 当 sample_limit > 0 时，仅考虑当前年度的 CVE 记录以简化示例。
if cf.SAMPLE_LIMIT > 0:
    initYear = currentYear

df = pd.DataFrame()

# ordered_cve_columns = ['cve_id', 'published_date', 'last_modified_date', 'description', 'nodes', 'severity',
#                        'obtain_all_privilege', 'obtain_user_privilege', 'obtain_other_privilege',
#                        'user_interaction_required',
#                        'cvss2_vector_string', 'cvss2_access_vector', 'cvss2_access_complexity', 'cvss2_authentication',
#                        'cvss2_confidentiality_impact', 'cvss2_integrity_impact', 'cvss2_availability_impact',
#                        'cvss2_base_score',
#                        'cvss3_vector_string', 'cvss3_attack_vector', 'cvss3_attack_complexity',
#                        'cvss3_privileges_required',
#                        'cvss3_user_interaction', 'cvss3_scope', 'cvss3_confidentiality_impact',
#                        'cvss3_integrity_impact',
#                        'cvss3_availability_impact', 'cvss3_base_score', 'cvss3_base_severity',
#                        'exploitability_score', 'impact_score', 'ac_insuf_info',
#                        'reference_json', 'problemtype_json']


ordered_cve_columns = ['cve_id', 'published_date', 'last_modified_date', 'description', 'nodes',
                       'cvss3_vector_string', 'cvss3_attack_vector', 'cvss3_attack_complexity',
                       'cvss3_privileges_required', 'cvss3_user_interaction', 'cvss3_scope',
                       'cvss3_confidentiality_impact', 'cvss3_integrity_impact', 'cvss3_availability_impact',
                       'cvss3_base_score', 'cvss3_base_severity', 'exploitability_score', 'impact_score',
                       'reference_json', 'problemtype_json']



cwe_columns = ['cwe_id', 'cwe_name', 'description', 'extended_description', 'url', 'is_category']

# ---------------------------------------------------------------------------------------------------------------------

def rename_columns(name):

    name = name.split('.', 2)[-1].replace('.', '_')
    name = re.sub(r'(?<!^)(?=[A-Z])', '_', name).lower()
    name = name.replace('cvss_v', 'cvss').replace('_data', '_json').replace('description_json', 'description')
    return name

def preprocess_jsons(df_in):
    """
    展平 CVE_Items 并删除重复项
    :param df_in: 合并所有年份 JSON 文件的数据框
    """
    cf.logger.info('展平 CVE 项目并删除重复项...')
    cve_items = json_normalize(df_in['CVE_Items'])
    df_cve = pd.concat([df_in.reset_index(), cve_items], axis=1)

    # 删除引用数据为空的所有 CVE 条目
    df_cve = df_cve[df_cve['cve.references.reference_data'].str.len() != 0]

    # 重新排序并过滤一些冗余和不必要的列
    df_cve = df_cve.rename(columns={'cve.CVE_data_meta.ID': 'cve_id'})
    df_cve = df_cve.drop(
        labels=[
            'index',
            'CVE_Items',
            'cve.data_type',
            'cve.data_format',
            'cve.data_version',
            'CVE_data_type',
            'CVE_data_format',
            'CVE_data_version',
            'CVE_data_numberOfCVEs',
            'CVE_data_timestamp',
            'cve.CVE_data_meta.ASSIGNER',
            'configurations.CVE_data_version',
            'impact.baseMetricV2.cvssV2.version',
            'impact.baseMetricV2.exploitabilityScore',
            'impact.baseMetricV2.impactScore',
            'impact.baseMetricV3.cvssV3.version',
        ], axis=1, errors='ignore')

    # 重命名列名
    df_cve.columns = [rename_columns(i) for i in df_cve.columns]

    # 排序 CVE 列
    df_cve = df_cve[ordered_cve_columns]

    return df_cve

def assign_cwes_to_cves(df_cve: pd.DataFrame):
    df_cwes = extract_cwe()
    # 获取 CWE 与 CVE 记录的关联
    cf.logger.info('将 CWE 分类添加到 CVE 记录...')
    df_cwes_class = df_cve[['cve_id', 'problemtype_json']].copy()
    df_cwes_class['cwe_id'] = add_cwe_class(df_cwes_class['problemtype_json'].tolist())  # CWE-ID 列表

    # 将 CVE 的多个 CWE 列表展开为多行
    df_cwes_class = df_cwes_class.assign(
        cwe_id=df_cwes_class.cwe_id).explode('cwe_id').reset_index()[['cve_id', 'cwe_id']]
    df_cwes_class = df_cwes_class.drop_duplicates(subset=['cve_id', 'cwe_id']).reset_index(drop=True)
    df_cwes_class['cwe_id'] = df_cwes_class['cwe_id'].str.replace('unknown', 'NVD-CWE-noinfo')

    no_ref_cwes = set(list(df_cwes_class.cwe_id)).difference(set(list(df_cwes.cwe_id)))
    if len(no_ref_cwes) > 0:
        cf.logger.debug('以下是 CVE 中没有关联到 cwe 表的 CWE 列表:')
        cf.logger.debug(no_ref_cwes)

    # 将断言应用于 cve、cwe 和 cwe_classification 表
    assert df_cwes.cwe_id.is_unique, "cwe 记录的主键不唯一！"
    assert df_cwes_class.set_index(['cve_id', 'cwe_id']).index.is_unique, \
        'cwe_classification 记录的主键不唯一！'
    assert set(list(df_cwes_class.cwe_id)).issubset(set(list(df_cwes.cwe_id))), \
        'cwe_classification 记录的所有外键并未全部在 cwe 表中找到！'

    df_cwes = df_cwes[cwe_columns].reset_index()  # 保持列顺序
    df_cwes.to_sql(name="cwe", con=db.conn, if_exists='replace', index=False)
    df_cwes_class.to_sql(name='cwe_classification', con=db.conn, if_exists='replace', index=False)
    cf.logger.info('已添加 cwe 和 cwe_classification 表')

def import_cves():
    """
    通过处理 JSON 文件收集 CVE 记录。
    """
    cf.logger.info('-' * 70)
    if db.table_exists('cve'):
        cf.logger.warning('cve 表已存在，加载并继续提取...')
        # df_cve = pd.read_sql(sql="SELECT * FROM cve", con=db.conn)
    else:
        for year in range(initYear, currentYear + 1):
            extract_target = 'nvdcve-1.1-' + str(year) + '.json'
            zip_file_url = urlhead + str(year) + urltail

            # 检查目录中是否已存在 json 文件
            if os.path.isfile(Path(cf.DATA_PATH) / 'json' / extract_target):
                cf.logger.warning(f'重新使用之前下载的 {year} 年的 CVE json 文件...')
                json_file = Path(cf.DATA_PATH) / 'json' / extract_target
            else:
                r = requests.get(zip_file_url)
                z = ZipFile(BytesIO(r.content))  # BytesIO 将文件保存在内存中
                json_file = z.extract(extract_target, Path(cf.DATA_PATH) / 'json')

            with open(json_file, encoding="utf8") as f:
                yearly_data = json.load(f)
                if year == initYear:  # 通过第一个年度数据初始化 df_methods
                    df_cve = pd.DataFrame(yearly_data)
                else:
                    df_cve = df_cve.append(pd.DataFrame(yearly_data))
                cf.logger.info(f'{year} 年的 CVE json 文件已合并')

        df_cve = preprocess_jsons(df_cve)
        df_cve = df_cve.applymap(str)
        assert df_cve.cve_id.is_unique, 'cve 记录的主键不唯一！'
        df_cve.to_sql(name="cve", con=db.conn, if_exists="replace", index=False)
        cf.logger.info('所有 CVE 已合并到 cve 表中')
        cf.logger.info('-' * 70)

        assign_cwes_to_cves(df_cve=df_cve)
